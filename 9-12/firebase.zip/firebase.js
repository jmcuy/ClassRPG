
var config = {
  apiKey: "AIzaSyCRNtGaHVfkfU6JwZj9BBSYfUpSXRJ0lIk",
  authDomain: "classrpg-2ac09.firebaseapp.com",
  databaseURL: "https://classrpg-2ac09.firebaseio.com",
  projectId: "classrpg-2ac09",
  storageBucket: "",
  messagingSenderId: "265529658530",
  appId: "1:265529658530:web:213f9c11a2a57002"
};
firebase.initializeApp(config);
